// OpenAI API configuration
const OPENAI_API_KEY = process.env.NEXT_PUBLIC_OPENAI_API_KEY || ""

export async function generateWorkoutPlan(userData: any) {
  try {
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${OPENAI_API_KEY}`,
      },
      body: JSON.stringify({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content:
              "You are a professional fitness trainer. Create a detailed 7-day workout plan based on the user data provided.",
          },
          {
            role: "user",
            content: `Create a personalized 7-day workout plan for someone with the following profile:
              - Fitness Level: ${userData.fitnessLevel}
              - Daily Routine: ${userData.dailyRoutine}
              - Available Time: ${userData.timeAvailable}
              - Age: ${userData.age}
              - Weight: ${userData.weight}
              - Height: ${userData.height}
              - Sex: ${userData.sex}
              
              Format the response as a JSON object with days of the week as keys (monday, tuesday, etc.), and for each day include:
              - title: A short title for the day's workout
              - exercises: An array of exercise objects, each containing:
                - name: Name of the exercise
                - sets: Number of sets (if applicable)
                - reps: Number of repetitions (if applicable)
                - duration: Duration (if applicable)
                - rest: Rest period (if applicable)
                - intensity: Intensity level (if applicable)
                - description: A brief description of how to perform the exercise correctly
              
              Make sure the plan is appropriate for their fitness level and available time.`,
          },
        ],
        temperature: 0.7,
        max_tokens: 2000,
      }),
    })

    const data = await response.json()
    if (data.error) {
      throw new Error(data.error.message)
    }

    // Parse the response to extract the workout plan
    const content = data.choices[0].message.content
    try {
      // Try to parse if it's directly JSON
      return JSON.parse(content)
    } catch (e) {
      // If not direct JSON, try to extract JSON from the text
      const jsonMatch = content.match(/```json\n([\s\S]*?)\n```/) || content.match(/{[\s\S]*}/)

      if (jsonMatch) {
        return JSON.parse(jsonMatch[1] || jsonMatch[0])
      } else {
        throw new Error("Could not parse workout plan from response")
      }
    }
  } catch (error) {
    console.error("Error generating workout plan:", error)
    return null
  }
}

export async function generateMealPlan(userData: any) {
  try {
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${OPENAI_API_KEY}`,
      },
      body: JSON.stringify({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content:
              "You are a professional nutritionist. Create a detailed meal plan based on the user data provided.",
          },
          {
            role: "user",
            content: `Create a personalized 1-day meal plan for someone with the following profile:
              - Food Preferences: ${userData.foodPreferences}
              - Daily Calorie Intake: ${userData.dailyCalorieIntake}
              - Age: ${userData.age}
              - Weight: ${userData.weight}
              - Height: ${userData.height}
              - Sex: ${userData.sex}
              
              Format the response as a JSON object with meal times as keys (breakfast, snack1, lunch, snack2, dinner), and for each meal include:
              - title: The meal time (Breakfast, Morning Snack, etc.)
              - meal: The name of the meal
              - ingredients: An array of ingredients with measurements
              - nutrition: An object with calories, protein, carbs, and fat
              - instructions: Brief instructions on how to prepare the meal
              - benefits: A brief note on the nutritional benefits of this meal
              
              Make sure the plan aligns with their food preferences and calorie needs.`,
          },
        ],
        temperature: 0.7,
        max_tokens: 2000,
      }),
    })

    const data = await response.json()
    if (data.error) {
      throw new Error(data.error.message)
    }

    // Parse the response to extract the meal plan
    const content = data.choices[0].message.content
    try {
      // Try to parse if it's directly JSON
      return JSON.parse(content)
    } catch (e) {
      // If not direct JSON, try to extract JSON from the text
      const jsonMatch = content.match(/```json\n([\s\S]*?)\n```/) || content.match(/{[\s\S]*}/)

      if (jsonMatch) {
        return JSON.parse(jsonMatch[1] || jsonMatch[0])
      } else {
        throw new Error("Could not parse meal plan from response")
      }
    }
  } catch (error) {
    console.error("Error generating meal plan:", error)
    return null
  }
}
