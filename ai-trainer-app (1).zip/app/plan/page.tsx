"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/context/auth-context"
import { db } from "@/lib/firebase"
import { doc, getDoc } from "firebase/firestore"
import InteractivePlanDisplay from "@/components/interactive-plan-display"
import { generateWorkoutPlan, generateMealPlan } from "@/lib/openai"

export default function PlanPage() {
  const { user, loading } = useAuth()
  const router = useRouter()
  const [userData, setUserData] = useState<any>(null)
  const [workoutPlan, setWorkoutPlan] = useState<any>(null)
  const [mealPlan, setMealPlan] = useState<any>(null)
  const [dataLoading, setDataLoading] = useState(true)
  const [aiLoading, setAiLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [isClient, setIsClient] = useState(false)

  // Set isClient to true when component mounts (client-side only)
  useEffect(() => {
    setIsClient(true)
  }, [])

  useEffect(() => {
    if (!loading && !user && isClient) {
      router.push("/")
      return
    }

    const fetchUserData = async () => {
      if (user && db && isClient) {
        try {
          const userDoc = await getDoc(doc(db, "users", user.uid))
          if (userDoc.exists()) {
            const data = userDoc.data()
            setUserData(data)

            // After getting user data, generate plans if they don't exist
            setAiLoading(true)

            try {
              // Generate workout plan
              const workoutPlanData = await generateWorkoutPlan(data)
              if (workoutPlanData) {
                setWorkoutPlan(workoutPlanData)
              }

              // Generate meal plan
              const mealPlanData = await generateMealPlan(data)
              if (mealPlanData) {
                setMealPlan(mealPlanData)
              }
            } catch (aiError: any) {
              console.error("Error generating AI plans:", aiError)
              setError("Could not generate personalized plans. Using default plans instead.")
            } finally {
              setAiLoading(false)
            }
          } else {
            // If no user data, redirect to onboarding
            router.push("/onboarding")
          }
        } catch (error) {
          console.error("Error fetching user data:", error)
          setError("Error loading your data. Please try again later.")
        } finally {
          setDataLoading(false)
        }
      }
    }

    if (user && isClient) {
      fetchUserData()
    } else if (isClient) {
      setDataLoading(false)
    }
  }, [user, loading, router, isClient])

  if (loading || dataLoading || !isClient) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
      </div>
    )
  }

  if (!user || !userData) {
    return null
  }

  return (
    <InteractivePlanDisplay
      userData={userData}
      workoutPlan={workoutPlan}
      mealPlan={mealPlan}
      isLoading={aiLoading}
      error={error}
    />
  )
}
